#!/system/bin/sh
MODID=anioptimizer
CONFIG_DIR="/data/adb/$MODID"

ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "     AniOptimizer V4 — Native C Daemon  "
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

[ ! -f "$MODPATH/bin/anioptimizerd" ] && \
    abort "✗ Binary missing — run termux_build.sh first"

set_perm_recursive "$MODPATH"         root root 0755 0644
set_perm "$MODPATH/service.sh"        root root 0755
set_perm "$MODPATH/uninstall.sh"      root root 0755
set_perm "$MODPATH/bin/anioptimizerd" root root 0755

# anictl CLI companion 
[ -f "$MODPATH/bin/anictl" ] && set_perm "$MODPATH/bin/anictl" root root 0755

mkdir -p "$CONFIG_DIR/calibration" "$CONFIG_DIR/learn" \
         "$CONFIG_DIR/state"       "$CONFIG_DIR/fingerprint" \
         "$CONFIG_DIR/backup"

[ ! -f "$CONFIG_DIR/default.conf"  ] && cp "$MODPATH/config/default.conf"  "$CONFIG_DIR/"
[ ! -f "$CONFIG_DIR/profiles.conf" ] && cp "$MODPATH/config/profiles.conf" "$CONFIG_DIR/"
[ ! -f "$CONFIG_DIR/game_list.txt" ] && cp "$MODPATH/config/game_list.txt" "$CONFIG_DIR/"
chmod 644 "$CONFIG_DIR"/*.conf "$CONFIG_DIR"/*.txt 2>/dev/null

rm -f "$CONFIG_DIR/disabled" "$CONFIG_DIR/safe_mode" \
      "$CONFIG_DIR/calibration/done" "$CONFIG_DIR/daemon.lock" 2>/dev/null

ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "- Config:  $CONFIG_DIR"
ui_print "- Log:     $CONFIG_DIR/boot.log"
ui_print "- CLI:     anictl status | reload | boost"
ui_print "  (use in Termux after reboot)"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "Reboot to activate."
