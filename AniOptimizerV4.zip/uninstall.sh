#!/system/bin/sh
MODID=anioptimizer
CONFIG_DIR="/data/adb/$MODID"

echo "AniOptimizer V4: stopping"
[ -f "$CONFIG_DIR/daemon.pid" ] && {
    PID=$(cat "$CONFIG_DIR/daemon.pid" 2>/dev/null)
    [ -n "$PID" ] && kill -TERM "$PID" 2>/dev/null && sleep 2
}

# Restore CPU governors
for g in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do
    [ -f "$g" ] && echo schedutil > "$g" 2>/dev/null
done

# Restore sched_boost
[ -f /proc/sys/kernel/sched_boost ] && echo 0 > /proc/sys/kernel/sched_boost 2>/dev/null
[ -f /sys/kernel/walt/sched_boost ] && echo 0 > /sys/kernel/walt/sched_boost 2>/dev/null

# Restore FPSGO
[ -f /sys/kernel/fpsgo/common/fpsgo_enable ] && echo 0 > /sys/kernel/fpsgo/common/fpsgo_enable 2>/dev/null

# Restore VM
[ -f "$CONFIG_DIR/backup/swappiness" ]      && cat "$CONFIG_DIR/backup/swappiness"      > /proc/sys/vm/swappiness 2>/dev/null
[ -f "$CONFIG_DIR/backup/cache_pressure" ]  && cat "$CONFIG_DIR/backup/cache_pressure"  > /proc/sys/vm/vfs_cache_pressure 2>/dev/null

# Restore IO
for q in /sys/block/*/queue/read_ahead_kb; do [ -f "$q" ] && echo 128 > "$q" 2>/dev/null; done
for q in /sys/block/*/queue/iostats;       do [ -f "$q" ] && echo 1   > "$q" 2>/dev/null; done

# Restore network
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null

# Restore IRQ affinity
for a in /proc/irq/*/smp_affinity_list; do [ -f "$a" ] && echo 0-7 > "$a" 2>/dev/null; done

rm -rf "$CONFIG_DIR"
echo "AniOptimizer V4: uninstalled"
