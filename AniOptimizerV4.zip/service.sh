#!/system/bin/sh
# AniOptimizer V4

MODDIR=$(dirname "$(readlink -f "$0")")
MODID=anioptimizer
DAEMON="$MODDIR/bin/anioptimizerd"
CONFIG_DIR="/data/adb/$MODID"
KILL_SWITCH="$CONFIG_DIR/disabled"
LOG="$CONFIG_DIR/boot.log"
PID_FILE="$CONFIG_DIR/daemon.pid"
LOCK_FILE="$CONFIG_DIR/daemon.lock"

mkdir -p "$CONFIG_DIR"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

log "=== service.sh V4 started (uid=$(id -u)) ==="

[ "$(id -u)" -ne 0 ] && { log "ERROR: not root"; exit 1; }
[ -f "$KILL_SWITCH" ] && { log "kill-switch present — skipping"; exit 0; }

if [ ! -x "$DAEMON" ]; then
    log "ERROR: daemon not found: $DAEMON"
    ls -la "$MODDIR/bin/" >> "$LOG" 2>&1
    exit 1
fi

# Wait for boot unless already booted
if [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; then
    log "waiting for boot_completed..."
    boot_wait=0
    until [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] \
       || [ "$boot_wait" -ge 120 ]; do
        sleep 2; boot_wait=$((boot_wait + 2))
    done
    sleep 5
fi
log "boot_completed OK"

# Kill any stale daemon
if [ -f "$PID_FILE" ]; then
    OLD=$(cat "$PID_FILE" 2>/dev/null)
    if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
        log "killing stale daemon pid=$OLD"
        kill -TERM "$OLD" 2>/dev/null
        i=0
        while kill -0 "$OLD" 2>/dev/null && [ "$i" -lt 10 ]; do
            sleep 0.5; i=$((i + 1))
        done
        kill -0 "$OLD" 2>/dev/null && kill -9 "$OLD" 2>/dev/null
        sleep 0.5
        log "stale daemon terminated"
    fi
    rm -f "$PID_FILE"
fi
rm -f "$LOCK_FILE"
log "lock file cleared"

# System libs first — avoids Termux RPATH issues under KSU
export LD_LIBRARY_PATH=/system/lib64:/vendor/lib64:/apex/com.android.runtime/lib64

log "launching anioptimizerd V4..."
"$DAEMON" >> "$LOG" 2>&1 &
DPID=$!
echo "$DPID" > "$PID_FILE"
log "daemon launched pid=$DPID"

sleep 2
if kill -0 "$DPID" 2>/dev/null; then
    log "daemon alive — OK"
else
    log "ERROR: daemon exited immediately — check binary / SELinux"
fi

log "service.sh V4 done"
exit 0
